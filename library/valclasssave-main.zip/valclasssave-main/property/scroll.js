let styles=" \n::-webkit-scrollbar { \n    display: none;\n}";document.getElementsByTagName("style")[0].appendChild(document.createTextNode(styles));
